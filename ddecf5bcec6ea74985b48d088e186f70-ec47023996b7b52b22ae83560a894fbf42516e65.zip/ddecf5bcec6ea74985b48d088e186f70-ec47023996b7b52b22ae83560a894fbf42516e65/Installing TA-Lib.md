# Installing TA-Lib
-------------------------------
- These tutorials basically have the same steps from 'install build-essential' thru '
sudo make install'

    - - https://gist.github.com/brunocapelao/ed1b4f566fccf630e1fb749e5992e964
    - - [https://joelzhang.medium.com/](https://joelzhang.medium.com/install-ta-lib-in-python-3-7-51219acacafb)
     - - [https://artiya4u.medium.com](https://artiya4u.medium.com/installing-ta-lib-on-ubuntu-944d8ca24eae)


 Dependences:
 



 - install build-essential
 - python-dev
 - install -U setuptools
 -  - `sudo apt install build-essential`
     -  Must be installed prior to installing ta-lib 
     -  [Explaination why build-essential is needed](https://stackoverflow.com/a/6486462)




### Steps:
1. Check python is installed
    `~/python-binance$ python3 --version`
2. Check if build-essential is installed already

    `~/python-binance$ apt list install build-essential`
    
3. check `python-dev` is installed
     `~/python-binance$ apt list install python-dev`
     if not installed then....
`~/python-binance$ sudo apt-get install python-dev`
     -   (this installs alot - takes awhile)
 4. Check python-pip is installed
    > not sure how to check if pip installed
    
    Install pip
     `~/python-binance$ sudo apt install python3-pip`
    
 5. Install `-U setuptools`
     `~/python-binance$ pip install -U setuptools`



  6. download from https://mrjbq7.github.io/ta-lib/install.html
        -    `Maybe dont follow instructions on this page` 
        
  7. copy ta-lib.tar download to venv dir
  8. untar ta-lib.tar.gz
      `~/python-binance$ sudo tar -xvf ta-lib-0.4.0-src.tar.gz`
      
  9. ` ~/python-binance$ cd ta-lib/ `
  10. `~/python-binance/ta-lib$ ./configure --prefix=/usr`
  11. `~/python-binance/python-binance/ta-lib$ make`
  12. `~/python-binance/ta-lib$ sudo make install`
  13. `~/python-binance/ta-lib$ pip install ta-lib`

```
tar -xvf ta-lib-0.4.0-src.tar.gz

cd /../ta-lib

./configure --prefix=/usr

make

sudo make install

sudo apt upgrade

pip install ta-lib or pip install TA-Lib

Check import talib
```

[TA-Lib install issue- StackOverflowPOST :](https://stackoverflow.com/q/65965371/15015450)

 - [reddit post:](https://redd.it/lzhvxm)

 - According to links below ta-lib should be installed in v-env in /lib/ dir.      
   -  i.e. `  /pythonstuff/python-binance/python-binance/lib/ta-lib/ta-lib# ` 
  
   - [install script from freqtrade for ta-lib](https://www.freqtrade.io/en/latest/installation/)
    - - sudo ./build_helpers/install_ta-lib.sh
 
   - https://github.com/mrjbq7/ta-lib/pull/75
   - [Stackoverflow python not finding libraries issue](https://stackoverflow.com/a/52458594)
   - [TA-Lib install candlestick-patterns-with-python-](https://stackoverflow.com/questions/64704974/how-to-install-python-ta-lib-library-in-azure-machine-learning-juypyter-notebook)
    - [TA-Lib install YOUTUBE and tutorial link](https://www.youtube.com/watch?v=AlFSxXP_d9M)
    - [Add support for TA-Lib binary installed in virtualenv.](https://github.com/mrjbq7/ta-lib/pull/75) venv not finding ta-lib libraries
    - [ install TA-Lib on Ubuntu](https://stackoverflow.com/questions/45406213/unable-to-install-ta-lib-on-ubuntu)
   
[ Cython python wrapper TA-LIB ](https://pypi.org/project/talib-binary/) - supposed to install easier than standard ta-lib

-----------------------

#### PIP related:

1. [pip ta-lib install](https://stackoverflow.com/questions/45406213/unable-to-install-ta-lib-on-ubuntu)
2. [$ pip install ta-lib](https://stackoverflow.com/a/65352752/15015450)
3. [$ pip install -i https://pypi.anaconda.org/masdeseiscaracteres/simple ta-lib](https://www.edureka.co/community/46414/unable-to-install-ta-lib-on-pycharm)
4. [Error when installing using pip](https://stackoverflow.com/questions/31498495/error-when-installing-using-pip)
5. [How to Install Pip on Debian 10](https://linuxize.com/post/how-to-install-pip-on-debian-10/)

